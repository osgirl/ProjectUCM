package hays.co.uk;

import intradoc.common.SystemUtils;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HaysUtil {
	public static final Pattern LOCALE_REGEX = Pattern.compile("(.+)[-_](.+)");
	
	public static Locale getLocale(String ucmLocale){
		String lang="en", country = "GB";
		Locale locale = null;
		if( ucmLocale != null && ucmLocale.trim().length() > 0){
			Matcher matcher = LOCALE_REGEX.matcher(ucmLocale);
			if (matcher.find() && matcher.groupCount() > 1){
	      		lang = matcher.group(1);
	    		country = matcher.group(2);
			}
		} 
		locale = new Locale(lang, country);
		return locale;
	}
	
	public static String getLanguageFromLocale(String locale){
		if(locale == null){
			return null;
		}
		String lang = null;
		Matcher matcher = LOCALE_REGEX.matcher(locale);
	    if (matcher.find() && matcher.groupCount() > 1) {
	    	lang = matcher.group(1);
	    }
		return lang;
	}
	
	
	public static String getCountryFromLocale(String locale){
		if(locale == null){
			return null;
		}
		String lang = null;
		Matcher matcher = LOCALE_REGEX.matcher(locale);
	    if (matcher.find() && matcher.groupCount() > 1) {
	    	lang = matcher.group(0);
	    }
		return lang;
	}
	public static void debug(Exception message) {
		SystemUtils.trace("hays_exception",  "Exception: " + message);
	}
	
	public static void trace(String message) {
		SystemUtils.trace("hays_general",  message);
	}
}
