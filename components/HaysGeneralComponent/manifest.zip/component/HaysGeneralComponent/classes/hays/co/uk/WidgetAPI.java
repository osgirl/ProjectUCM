package hays.co.uk;
import java.util.Currency; 
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern; 
import com.hp.hpl.jena.ontology.OntModel;
import hays.co.uk.search.HaysSearchLocationsHandler;
import intradoc.common.ClassHelper;
import intradoc.common.ExecutionContext;
import intradoc.common.IdcStringBuilder;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.data.ResultSet;
import intradoc.data.Workspace;
import intradoc.provider.Provider;
import intradoc.provider.Providers;
import intradoc.server.Service;
import intradoc.server.ServiceHandler;
import intradoc.shared.FilterImplementor;
import intradoc.shared.SharedObjects;
import intradoc.util.IdcMessage;
import infomentum.ontology.*;
import infomentum.ontology.loader.OntologyFacade;
import infomentum.ontology.navigation.OntologyNavigationHandler;
import hays.custom.multilingual.HaysWebSite;
import java.util.HashMap;
import java.util.Properties; 
import java.util.Calendar;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat; 
import static hays.com.commonutils.HaysWebApiUtils.HandleExceptions;

import java.io.IOException;

import intradoc.common.LocaleUtils;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.server.ServiceHandler;

public class WidgetAPI  extends ServiceHandler{
	
	 public void getWidgetDetails() throws ServiceException, DataException

     {

     // get the all required parameters from the binder.

     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler : getWidgetDetails:");

     String locale = this.m_binder.getLocal("locale");
     locale = (locale.trim().length() > 0) ? locale : "%";
     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Locale: " +locale);

     String page_name = this.m_binder.getLocal("page_name");
     page_name = (page_name.trim().length() > 0) ? page_name : "%";
     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Page Name: " +page_name);

     String providerName = this.m_currentAction.getParamAt(0);
     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Provider Name: " +providerName);

     String resultSetName = this.m_currentAction.getParamAt(1);
     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Result Set Name: " +resultSetName);

     String queryName = this.m_currentAction.getParamAt(2);
     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Query Name: " +queryName);
     String queryName1 = this.m_currentAction.getParamAt(3);
     SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Query Name: " +queryName1);

     this.m_binder.putLocal("locale", locale);
     this.m_binder.putLocal("page_name", page_name);
     Workspace ws = getProviderConnection(providerName);

     DataResultSet result = null;

    

                     

                    	 if (queryName != null && queryName.trim().length() > 0)

                    	 {

                                     ResultSet temp = ws.createResultSet(queryName, m_binder);

                                     result = new DataResultSet();

                                     result.copy(temp);
                    	 }

                     
    
    
     this.m_binder.addResultSet(resultSetName, result);
		this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwWebApiOKMsg", null));
		this.m_binder.putLocal("StatusCode", "UC000");
		// release the JDBC connection assigned to this thread (request)
		// which kills the result set 'temp'
		ws.releaseConnection();
		
		this.m_binder.removeResultSet("WidgetRS");
		this.m_binder.removeLocal("locale");
		this.m_binder.removeLocal("page_name");
 
     }

   private Workspace getProviderConnection(String providerName) throws ServiceException, DataException
                 	{

                 		SystemUtils.trace("hays_search", "provider name to be used =" + providerName);
                 		// validate the provider name
                 		if (providerName == null || providerName.length() == 0)
                 		{
                 			throw new ServiceException("You must specify a provider name.");
                 		}
                 		// validate that the provider is a valid database provider
                 		Provider p = Providers.getProvider(providerName);
                 		if (p == null)
                 		{
                 			throw new ServiceException("The provider '" + providerName + "' does not exist.");
                 		}
                 		else if (!p.isProviderOfType("database"))
                 		{
                 			throw new ServiceException("The provider '" + providerName + "' is not a valid provider of type 'database'.");
                 		}

                 		Workspace ws = (Workspace) p.getProvider();

                 		return ws;
                 	}
     
   public void getPageWidgetsFromDB() throws DataException, ServiceException
   {
    String providerName = m_currentAction.getParamAt(0);
    String resultSetName = m_currentAction.getParamAt(1);
    String queryName = m_currentAction.getParamAt(2); 
    SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Provider Name: " +providerName);
    SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Resultset Name: " +resultSetName);
    SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Query Name: " +queryName);
    
    Workspace ws = getProviderConnection(providerName);
    
    DataResultSet result = null;
    if (queryName != null && queryName.trim().length() > 0)
    {
     ResultSet temp = ws.createResultSet(queryName, m_binder);
     result = new DataResultSet();
     result.copy(temp);
     SystemUtils.trace("widgetdata", "Inside getPageWidgetsFromDB If condition: ");
    }
    m_binder.addResultSet(resultSetName, result);
    ws.releaseConnection();
   }
   
   public void setWidgetDetails() throws ServiceException, DataException

   {

   // get the all required parameters from the binder.

   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler : setWidgetDetails:");
	 String locale = this.m_binder.getLocal("locale");
   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Locale: " +locale);
	 String page_name = this.m_binder.getLocal("page_name");
   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Page Name: " +page_name);
	 String widget_name = this.m_binder.getLocal("widget_name");
   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler widget_name: " +widget_name);
	 String widget_order = this.m_binder.getLocal("widget_order");
   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler widget_order: " +widget_order);
	 String providerName = this.m_currentAction.getParamAt(0);
   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Provider Name: " +providerName);
	 String queryName = this.m_currentAction.getParamAt(1);
   SystemUtils.trace("widgetdata", "Inside WidgetDataHandler Query Name: " +queryName);
	 Workspace ws = getProviderConnection(providerName);
		String delQuery = "delete from widget_mapping where locale = '"+locale+"' and page_name = '"+page_name+"'";
		String[] parts = widget_name.split(",");
		int length = parts.length;
		 SystemUtils.trace("widgetdata", "length: " +length);
   if (locale != null && locale.trim().length() > 0)
	{
		if (page_name != null && page_name.trim().length() > 0)
			 {
			 if (queryName != null && queryName.trim().length() > 0)
			try {
				 SystemUtils.trace("widgetdata", "delQuery: " +delQuery);
				ws.executeSQL(delQuery);
				for (int i = 0; i<= length; i++)
					{
						
						String insertQ = "insert into widget_mapping values ('"+page_name+"','"+locale+"','"+parts[i]+"',"+i+")";
						     SystemUtils.trace("widgetdata", "insertQ: " +insertQ);
						ws.executeSQL(insertQ);
					}
			}catch(Exception ex){
				//debug("Insert new complex metadata failed: " + ex);
							}
					}
   }
   ws.releaseConnection();
   }
   
  }

