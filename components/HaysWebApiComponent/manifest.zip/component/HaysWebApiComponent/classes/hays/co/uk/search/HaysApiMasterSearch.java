package hays.co.uk.search;

import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.server.ServiceHandler;
import intradoc.shared.SharedObjects;

public class HaysApiMasterSearch extends ServiceHandler
{

	public final static String TRACE_NAME = "HAYS_API_MASTER_SEARCH";
	public static final String RESULTSET_HAYSLOCALEDETAILS = "LOCALE_DETAILS";

	public void selectSearchMethod() throws DataException, ServiceException
	{
		String[] GoogleSearchCountryList = SharedObjects.getEnvironmentValue("GoogleSearchFormAPI").split(",");
		boolean googleSearchCountry = false;
		boolean islinkedin = false;
		String linkedInParam = getData("islinkedin");
		if ("Y".equalsIgnoreCase(linkedInParam))
		{
			islinkedin = true;
		}
		if (!islinkedin)
		{
			DataResultSet drsSearchResults = new DataResultSet();
			drsSearchResults = (DataResultSet) super.m_binder.getResultSet(RESULTSET_HAYSLOCALEDETAILS);
			SystemUtils.trace(TRACE_NAME, "ISO Country Code: " + drsSearchResults.getStringValueByName("ISOCOUNTRYCODE").toString());
			for (String s : GoogleSearchCountryList)
			{
				if (drsSearchResults.getStringValueByName("ISOCOUNTRYCODE").equalsIgnoreCase(s))
				{
					googleSearchCountry = true;
					break;
				}
			}
		}
		String contentType = getData(IHaysSearchConstants.CONTENT_TYPE);

		if (!islinkedin && googleSearchCountry && "Jobs".equals(contentType))
		{
			m_service.executeServiceEx("HAYS_API_GOOGLE_SEARCH_RESULTS", true);
			SystemUtils.trace(TRACE_NAME, "Executed service :: HAYS_API_GOOGLE_SEARCH_RESULTS");
		}
		else
		{
			m_service.executeServiceEx("HAYS_API_GET_SEARCH_RESULTS", true);
			SystemUtils.trace(TRACE_NAME, "Executed service :: HAYS_API_GET_SEARCH_RESULTS");
		}
	}
	
	public String getData(String pParamName)
	{
		String returnString = "";
		try
		{
			returnString = m_binder.get(pParamName);
			if("null".equalsIgnoreCase(returnString))
			{
				returnString = "";
			}

		}
		catch (Exception e)
		{

		}
		return returnString.trim();
	}

}
