package hays.co.uk.search;

import static hays.com.commonutils.HaysWebApiUtils.*;
import intradoc.common.LocaleUtils;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.data.FieldInfo;
import intradoc.data.ResultSet;
import intradoc.data.ResultSetUtils;
import intradoc.data.Workspace;
import intradoc.provider.Provider;
import intradoc.provider.Providers;
import intradoc.server.ServiceHandler;
import intradoc.shared.SharedObjects;
import java.io.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class HaysAddExtraFields extends ServiceHandler {
	
	public static final String RESULTSET_SEARCHRESULTS 	= "SearchResults";
	public static final String RESULTSET_HAYSDOCINFO 	= "HAYS_DOC_INFO";
	public static final int TOP_LEVEL= 1;
	public static final int BOTTOM_LEVEL=6;
	public static final String HAYS_LOCATION_FORMAT="xHaysLocation";
	
	//This function is used for adding SponsoredJob ImageUrl in ResultSet SearchResults
	public void addSponsoredJobImageUrl() throws DataException, ServiceException {
		
		java.util.Date date= new java.util.Date();
		Timestamp currentTimestamp = new java.sql.Timestamp(date.getTime());			
		SystemUtils.trace("webapi_jobdetail", "function addSponsoredJobImageUrl Start Time: "+currentTimestamp);
		
		
		StringBuffer sponsoredEmployers = new StringBuffer(100);
		String sEmployerDocNameList="";
		String filelocation=null;
		String webLayoutlUrl=SharedObjects.getEnvironmentValue("WeblayoutDir");			
		String securityGroup="";
		String docAccount="";
		String doctype="";
		String fileExtension="";
		String sponsoredEmployerDocName="";
		ArrayList<String> sponsoredImageUrls = new ArrayList<String>();	
		ArrayList<String> tempSponsoredImageUrls = new ArrayList<String>();	
		DataResultSet sponsoreImageResultSet = null;
		String flag=m_binder.getLocal("isjobDetail");
		DataBinder docParams = new DataBinder();
		Vector vSearchresults=null;
		int fieldIndex=0;
		
		
		if(m_binder.getLocal("isMobile")!=null && m_binder.getLocal("isMobile").equals("Y"))
        {
			DataResultSet drsSearchResults =new DataResultSet();
			if(flag!=null && ("Y").equalsIgnoreCase(flag))
			{
				drsSearchResults=(DataResultSet)super.m_binder.getResultSet(RESULTSET_HAYSDOCINFO);
			}
			else
			{
				drsSearchResults=(DataResultSet)super.m_binder.getResultSet(RESULTSET_SEARCHRESULTS);
			}
			if(drsSearchResults!=null)
			 {				
			
			if(drsSearchResults.getNumRows()>0)
	        {
			SystemUtils.trace("webapi_search", "ResultSet SearchResults total rows: "+ drsSearchResults.getNumRows());			
			
			fieldIndex = drsSearchResults.getNumFields();
			
			Vector<FieldInfo> sponsoredImage = new Vector<FieldInfo>();
	        FieldInfo SporedImageFieldInfo = new FieldInfo();
	        SporedImageFieldInfo.m_name="SponsoredJobsImage";
	        SporedImageFieldInfo.m_type = 6;
	        sponsoredImage.add(SporedImageFieldInfo);
	        drsSearchResults.appendFields(sponsoredImage);
	        
	        Vector<FieldInfo> locationLongLat = new Vector<FieldInfo>();
	        FieldInfo locationLongLatInfo = new FieldInfo();
	        locationLongLatInfo.m_name="HaysLocations";
	        locationLongLatInfo.m_type = 6;
	        locationLongLat.add(locationLongLatInfo);
	        drsSearchResults.appendFields(locationLongLat);	        
	        
	        String sponsoredJobImageUrl="";
	        
			do{
	        	
        		int currentRowIndex =  drsSearchResults.getCurrentRow();        	
	        	String HaysLocationsByLevel="";
        		String locationId = drsSearchResults.getCurrentRowMap().get("xLocation").toString().trim();        		
        		SystemUtils.trace("webapi_search", "Job Location ID and Description : " +locationId+"##"+drsSearchResults.getCurrentRowMap().get("xLocationDescription").toString());	
       		    if(locationId!=null && locationId.length()>0)
       		    {    
       		    	Object retrieved=null;
       		    	for( int i = BOTTOM_LEVEL; i >= TOP_LEVEL; i--) {
       		    		HaysLocationsByLevel=HAYS_LOCATION_FORMAT+i;
       		    		SystemUtils.trace("webapi_search", "HaysLocationsByLevel : " +HaysLocationsByLevel);
       		    		retrieved = drsSearchResults.getCurrentRowMap().get(HaysLocationsByLevel);
       	       		    if(retrieved != null && retrieved.toString().length()>0)
       					{
       	       		    	SystemUtils.trace("webapi_search", "HaysLocation By Level : " +drsSearchResults.getCurrentRowMap().get(HaysLocationsByLevel).toString());	
       	       		    	vSearchresults = drsSearchResults.getCurrentRowValues();	   
       	       		    	vSearchresults.set(fieldIndex+1, drsSearchResults.getCurrentRowMap().get(HaysLocationsByLevel).toString()); 
       						break;
       					}
       							
       				}
       		    	       		
        		}
        		
        		
	        
        		 
        		if(drsSearchResults.getCurrentRowMap().get("xSponsored").toString()!=null && drsSearchResults.getCurrentRowMap().get("xSponsored").toString().length()>0)
        		{
        			sponsoredEmployers=sponsoredEmployers.append("','").append(drsSearchResults.getCurrentRowMap().get("xSponsored").toString());
        		}        		
        		
	        }while(drsSearchResults.next());
			
			SystemUtils.trace("webapi_search","SponsoredEmployers DocName list ="+ sponsoredEmployers);				
				
			
			
		if(sponsoredEmployers!=null && sponsoredEmployers.length()>0)
		  {
			
			sEmployerDocNameList=sponsoredEmployers.substring(3,sponsoredEmployers.length());
			SystemUtils.trace("webapi_search","Final SponsoredEmployers DocName list ="+ sEmployerDocNameList);	       
	        
	        
	        docParams.putLocal("SEmployerDocNameList", sEmployerDocNameList); 
	        
	        Provider p = Providers.getProvider("SystemDatabase");	    	    
	        Workspace databaseServerWs = (Workspace)p.getProvider();
			ResultSet sponsoredEmployersrset = databaseServerWs.createResultSet("QGetSponsoredEmployersDetails", docParams);
			DataResultSet sponsoredEmployersdrset=new DataResultSet(); 
			sponsoredEmployersdrset.copy(sponsoredEmployersrset);
			
			SystemUtils.trace("webapi_search","SponsoredEmployers dRSet ="+ sponsoredEmployersdrset);
			
			sponsoredImageUrls.add("xSponsored"); 
        	sponsoredImageUrls.add("SponsoredJobsImage");
        	
        	if (sponsoredEmployersdrset.getNumRows()>0)
        	{
        		do{
    	        	
            		int currentRowIndex =  sponsoredEmployersdrset.getCurrentRow();
            		 
            		//Define variables for creating content file path
        			webLayoutlUrl=SharedObjects.getEnvironmentValue("WeblayoutDir");			
        			securityGroup=sponsoredEmployersdrset.getStringValueByName("dSecurityGroup");
        			docAccount=sponsoredEmployersdrset.getStringValueByName("dDocAccount");
        			doctype=sponsoredEmployersdrset.getStringValueByName("dDocType");
        			fileExtension=sponsoredEmployersdrset.getStringValueByName("dWebExtension");    			   			
        			sponsoredEmployerDocName=sponsoredEmployersdrset.getStringValueByName("dDocName");
        			
        			if (docAccount != null && docAccount.length() > 0)
        			{
        				if(docAccount.indexOf("/")>0)
        				{
        					docAccount=docAccount.replaceAll("/", "/@");
        					docAccount="@"+docAccount;						
        				}
        				else
        				{
        					docAccount="@"+docAccount;
        				}
        				
        				filelocation="groups/"+securityGroup+"/"+docAccount+"/documents/"+doctype+"/"+sponsoredEmployerDocName+"."+fileExtension;
        			}
        			
        			else
        			{
        				filelocation="groups/"+securityGroup+"/documents/"+doctype+"/"+sponsoredEmployerDocName+"."+fileExtension;
        			}
        			
        			filelocation=filelocation.toLowerCase();
        			filelocation=webLayoutlUrl+filelocation;
        			SystemUtils.trace("webapi_search", "File URL: "+filelocation);
        			
        			try
        			{
        				
        				DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        	            DocumentBuilder docBuilder = null;
        				docBuilder = docBuilderFactory.newDocumentBuilder();
        				Document doc = null;
        				doc = docBuilder.parse (filelocation);				
        	            doc.getDocumentElement().normalize();
        	
        	            //SystemUtils.trace("webapi_search", "Root element of the doc is: "+doc.getDocumentElement().getNodeName());
        	            
        	            NodeList ndlst = doc.getElementsByTagName("wcm:element");	
        	            int totalElements = ndlst.getLength();
        	           
        	            //SystemUtils.trace("webapi_search", "Total no of doc elements : "+totalElements);            
        	           
        	
        	            for(int s=0; s<ndlst.getLength() ; s++){
        	            	
        	            	Node firstPersonNode = ndlst.item(s);	            	
        	            	if(firstPersonNode.getNodeType() == Node.ELEMENT_NODE){
        	
        	            	Element firstElement = (Element)firstPersonNode;
        	            	//SystemUtils.trace("webapi_search", "XML element Name : " +firstElement.getAttribute("name").trim());
        	            	  	
        	            	Node nd = firstElement.getFirstChild();
        	            	if("Image".equalsIgnoreCase(firstElement.getAttribute("name").trim()) && nd.getNodeValue().toString()!=null)
        	            	{
        	            		//SystemUtils.trace("webapi_search", "XML element Text : " +nd.getNodeValue());
        	            		          	
            	            	String elementContent=nd.getNodeValue().trim();
            	            	
            	            	int imageSrcStartIndex=elementContent.indexOf("wcmUrl");
            	            	int imageSrcEndIndex=elementContent.indexOf("')");
            	            	String imagePath=elementContent.substring(imageSrcStartIndex+19, imageSrcEndIndex);
            	            	
            	            	
            	            	tempSponsoredImageUrls.add(sponsoredEmployerDocName);
            	            	tempSponsoredImageUrls.add(imagePath);
        	            	}   	            	 	            	
        	                    		
        	        		
        					}
        					
        				}
                    
        			}
        			 			
        			
        			catch (ParserConfigurationException e)
        			{
        				// TODO Auto-generated catch block
        				this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwFileNotParse", null));
        				this.m_binder.putLocal("StatusCode", "UC012");
        				throw new ServiceException(LocaleUtils.encodeMessage("wwFileNotParse", null));
        			}
        			catch (SAXException e)
        			{
        				// TODO Auto-generated catch block				
        				this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwFileNotFormedProperly", null));
        				this.m_binder.putLocal("StatusCode", "UC012");			
        				throw new ServiceException(LocaleUtils.encodeMessage("wwFileNotFormedProperly", null));
        			} 
        			catch (IOException e)
        			{
        				// TODO Auto-generated catch block				
        				this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwFileNotFound", null));
        				this.m_binder.putLocal("StatusCode", "UC011");			
        				throw new ServiceException(LocaleUtils.encodeMessage("wwFileNotFound", null));
        			}    			
        		    		
    	        }while(sponsoredEmployersdrset.next());
    			
    		  
    			SystemUtils.trace("webapi_search", "Sponsored Employer ImageUrls List1 : " +sponsoredImageUrls);	
    			SystemUtils.trace("webapi_search", "Sponsored Employers ImageUrls List2: " +tempSponsoredImageUrls);
    			
    			
    			sponsoreImageResultSet=(DataResultSet)createResultSetFromData(sponsoredImageUrls, tempSponsoredImageUrls);			
    			SystemUtils.trace("webapi_search", "SponsoredImage ResultSet : " +sponsoreImageResultSet);	
        	 
    			//Adding sponsoredImageUrl in Sponsored Jobs
    			if(drsSearchResults.first())
    			{
    						        
    		        do{
    		        	//SystemUtils.trace("webapi_search",  "\nIn while: " + fieldIndex);
    	        		int currentRowIndex =  drsSearchResults.getCurrentRow();
    	        		String sponsoredDocName = drsSearchResults.getCurrentRowMap().get("xSponsored").toString();
    	        		if(drsSearchResults.getCurrentRowMap().get("xSponsored").toString()!=null && drsSearchResults.getCurrentRowMap().get("xSponsored").toString().length()>0)
    	        		{
    	        		SystemUtils.trace("webapi_search", "Sponsored DocName while merging in ResultSet SearchResults : " +sponsoredDocName);	
    	        		Vector vSponsored = sponsoreImageResultSet.findRow(0, sponsoredDocName);
    	        		SystemUtils.trace("webapi_search", "Vector vSponsored : " +vSponsored);
    	        		if(vSponsored!=null && !(vSponsored.isEmpty()))
    	        		{
    	        			sponsoredJobImageUrl=vSponsored.get(1).toString();	    
    	        		}
    	        		    		
    	        		vSearchresults = drsSearchResults.getCurrentRowValues();	        		
    	        		vSearchresults.set(fieldIndex, sponsoredJobImageUrl);
    	        		
    	        		SystemUtils.trace("webapi_search", "Sponsored Job DocName : " +drsSearchResults.getCurrentRowMap().get("dDocName").toString());	
    	        		SystemUtils.trace("webapi_search", "Sponsored Employer DocName : " +drsSearchResults.getCurrentRowMap().get("xSponsored").toString());	
    	        		SystemUtils.trace("webapi_search", "Sponsored Image URL : " +sponsoredJobImageUrl);	
    	        		}
    		        }while(drsSearchResults.next());
    			}
        	
        	}
        	
        	
		  
		 }
		
		/*if(drsSearchResults.first())
		{
					        
	        do{}while(drsSearchResults.next());
		}*/
		
		
			//Removing xSponsored[custom metadata field] response parameter
			String removeFields[]={"xSponsored","xLocation","xHaysLocation1","xHaysLocation2","xHaysLocation3","xHaysLocation4","xHaysLocation5","xHaysLocation6"};
			drsSearchResults.removeFields(removeFields);
			
			this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwWebApiOKMsg", null));
			this.m_binder.putLocal("StatusCode", "UC000"); 
	        }
		
		 }	
						
		
        }
		
		java.util.Date date1= new java.util.Date();
		Timestamp currentTimestamp1 = new java.sql.Timestamp(date1.getTime());			
		SystemUtils.trace("webapi_jobdetail", "function addSponsoredJobImageUrl End Time: "+currentTimestamp1);
		
		
	}
	
	

}
