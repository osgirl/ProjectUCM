package hays.custom;

import static hays.com.commonutils.HaysWebApiUtils.createResultSetFromData;
import static hays.com.commonutils.HaysWebApiUtils.isNotNull;
import static hays.com.commonutils.HaysWebApiUtils.parseXML;
import hays.com.commonutils.HaysWebApiUtils;
import hays.com.commonutils.NamespaceResolver;
import intradoc.common.DataStreamWrapper;
import intradoc.common.ExecutionContext;
import intradoc.common.LocaleUtils;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.data.ResultSet;
import intradoc.filestore.FileStoreUtils;
import intradoc.filestore.IdcFileDescriptor;
import intradoc.server.ServiceHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class HaysJobCandDetails extends ServiceHandler
{

	public final static String TRACE_NAME = "webapi_jobdetail";

	public void getHaysJobCandDetails() throws ServiceException, DataException, XPathExpressionException
	{
		String databaseproviderName = this.m_currentAction.getParamAt(0);
		String docInfoResultSetName = this.m_currentAction.getParamAt(1);
		String primaryfileResultSetName = this.m_currentAction.getParamAt(2);
		String docInfoInternalResultSetName = this.m_currentAction.getParamAt(4);
		DataResultSet haysContent = new DataResultSet();
		String dDocName = m_binder.getLocal("dDocName");

		SystemUtils.trace(TRACE_NAME, "databaseproviderName: " + databaseproviderName);
		SystemUtils.trace(TRACE_NAME, "docInfoResultSetName: " + docInfoResultSetName);
		SystemUtils.trace(TRACE_NAME, "primaryfileResultSetName: " + primaryfileResultSetName);
		SystemUtils.trace(TRACE_NAME, "dDocName: " + dDocName);
		String filelocation = getFile();
		SystemUtils.trace(TRACE_NAME, filelocation);
		SystemUtils.trace(TRACE_NAME, "File URL: " + filelocation);
		try
		{
			ArrayList<String> lData = null;
			ResultSet lResultSet = null;
			Document lDoc = null;
			lDoc = parseXML(filelocation);
			lData = getJobCandDesc(lDoc);
			ArrayList<String> lHeaderList = new ArrayList<String>();
			lHeaderList.add("Title");
			lHeaderList.add("Summary");
			lHeaderList.add("LinkedInJobSummary");
			lResultSet = createResultSetFromData(lHeaderList, lData);
			haysContent.copy(lResultSet);
			if (m_binder.getLocal("islinkedin") != null && !"".equalsIgnoreCase(m_binder.getLocal("islinkedin"))
					&& ("Y".equalsIgnoreCase(m_binder.getLocal("islinkedin")) || "Yes".equalsIgnoreCase(m_binder.getLocal("islinkedin"))))
			{
				String removeSummaryField[] = { "Summary" };
				haysContent.removeFields(removeSummaryField);
			}
			else
			{
				String removeLinkedInField[] = { "LinkedInJobSummary" };
				haysContent.removeFields(removeLinkedInField);
			}
		}
		catch (ParserConfigurationException e)
		{
			this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwFileNotParse", null));
			this.m_binder.putLocal("StatusCode", "UC012");
		}
		catch (SAXException e)
		{
			this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwInvalidJobDetailParameters", null));
			this.m_binder.putLocal("StatusCode", "UC008");
		}
		catch (IOException e)
		{
			this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwInvalidJobDetailParameters", null));
			this.m_binder.putLocal("StatusCode", "UC008");
		}

		DataResultSet drs = (DataResultSet) this.m_binder.getResultSet(docInfoInternalResultSetName);
		SystemUtils.trace(TRACE_NAME, "HAYS_DOC_INFO ResultSet : " + drs);
		SystemUtils.trace(TRACE_NAME, "HAYS_DATA ResultSet : " + haysContent);

		String removeExtraFields[] = { "dDocType", "dSecurityGroup", "dDocAccount", "dDocType", "dWebExtension", "xRefDomainId",
				"xRefJobId" };
		drs.removeFields(removeExtraFields);

		if (drs != null && drs.getNumRows() > 0)
		{
			this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwWebApiOKMsg", null));
			this.m_binder.putLocal("StatusCode", "UC000");
			m_binder.addResultSet(docInfoResultSetName, drs);
		}

		if (haysContent != null && haysContent.getNumRows() > 0)
		{
			m_binder.addResultSet(primaryfileResultSetName, haysContent);
		}

		getJobLocaleAndDomain();
		SystemUtils.trace(TRACE_NAME, "Fetched locale details as per job's locale successfully.");
	}

	public ArrayList<String> getJobCandDesc(Document lDocument) throws XPathExpressionException
	{
		XPath xpath = XPathFactory.newInstance().newXPath();
		xpath.setNamespaceContext(new NamespaceResolver());
		ArrayList<String> lresult = new ArrayList<String>();
		XPathExpression expr = xpath.compile("//wcm:root/wcm:element[@name='Title']/text()");
		lresult.add(expr.evaluate(lDocument, XPathConstants.STRING).toString());
		expr = xpath.compile("//wcm:root/wcm:element[@name='Summary']/text()");
		lresult.add(expr.evaluate(lDocument, XPathConstants.STRING).toString());
		expr = xpath.compile("//wcm:root/wcm:element[@name='LinkedInJobSummary']/text()");
		lresult.add(expr.evaluate(lDocument, XPathConstants.STRING).toString());
		return lresult;
	}

	public String getFile()
	{
		DataStreamWrapper localDataStreamWrapper = m_service.getDownloadStream(true);
		try
		{
			String str2 = this.m_binder.getAllowMissing("Rendition");
			if ((str2 == null) || (str2.equalsIgnoreCase("primary")))
			{
				str2 = "primaryFile";
			}
			m_binder.putLocal("RenditionId", str2);
			IdcFileDescriptor localIdcFileDescriptor = null;
			localIdcFileDescriptor = m_service.m_fileStore.createDescriptor(m_binder, null, (ExecutionContext) m_service);
			SystemUtils.trace(TRACE_NAME, localIdcFileDescriptor.toString());
			localDataStreamWrapper.m_descriptor = localIdcFileDescriptor;
			FileStoreUtils.forceDownloadStreamToFilePath(localDataStreamWrapper, m_service.m_fileStore, (ExecutionContext) m_service);
		}
		catch (Exception localException)
		{
			localException.printStackTrace();
		}

		return localDataStreamWrapper.m_filePath;
	}

	private void getJobLocaleAndDomain() throws ServiceException, DataException
	{
		String providerName = "SystemDatabase";
		String lLocale = null;
		String lDomainId = null;
		DataResultSet lLocaleDetails = null;
		DataResultSet lDocInfo = (DataResultSet) m_binder.getResultSet("DOC_INFO");
		if (lDocInfo != null && lDocInfo.getNumRows() > 0)
		{
			lLocale = lDocInfo.getStringValueByName("xLocale");
			SystemUtils.trace(TRACE_NAME, "Locale of job is : " + lLocale);
		}
		if (isNotNull(lLocale))
		{
			m_binder.putLocal("sitelocale", lLocale.trim());
			lLocaleDetails = HaysWebApiUtils.executeHaysProviderQuery(providerName, "QGetLocaleDetails", m_binder);
			if (lLocaleDetails != null && lLocaleDetails.getNumRows() > 0)
			{
				lDomainId = lLocaleDetails.getStringValueByName("DOMAINID");
				SystemUtils.trace(TRACE_NAME, "Live website domain id is : " + lDomainId);
			}
			if (!isNotNull(lDomainId))
			{
				lLocaleDetails = HaysWebApiUtils.executeHaysProviderQuery(providerName, "QGetNonLiveSitesDomainId", m_binder);
				if (lLocaleDetails != null && lLocaleDetails.getNumRows() > 0)
				{
					lDomainId = lLocaleDetails.getStringValueByName("DOMAINID");
					lLocale = lLocaleDetails.getStringValueByName("SITELOCALE");
					SystemUtils.trace(TRACE_NAME, "Non-Live website domain id is : " + lDomainId);
				}
			}
		}
		lLocaleDetails = new DataResultSet(new String[] { "SITE_LOCALE", "DOMAIN_ID" });
		lLocaleDetails.addRowWithList(Arrays.asList(new String[] { lLocale, lDomainId }));
		m_binder.addResultSet("LOCALE_DETAILS", lLocaleDetails);
	}
}
