package hays.custom;

import static hays.com.commonutils.HaysWebApiUtils.HandleExceptions;
import hays.com.commonutils.EntityHaysWebsites;
import hays.com.commonutils.HaysWebApiUtils;
import intradoc.common.LocaleUtils;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.server.ServiceHandler;

public class HaysWebApiRegisterVacancy  extends ServiceHandler
{
	public final static String TRACE_NAME = "webAPI_webApiRegisterVacancy";

	public void webApiRegisterVacancy() throws ServiceException, DataException
	{
		
			try
			{
				String lLocale = m_binder.getLocal("locale");
				SystemUtils.trace(TRACE_NAME, "lLocale " + lLocale);
				EntityHaysWebsites lEntityHaysWebsites = HaysWebApiUtils.getHaysWebsitesData((DataResultSet) this.m_binder
						.getResultSet("LOCALE_DETAILS"));
				m_binder.putLocal("your_organisation",getData("organisation"));
				m_binder.putLocal("your_name",getData("name"));
				m_binder.putLocal("telephone",getData("telephone"));
				m_binder.putLocal("email",getData("fromEmail"));
				m_binder.putLocal("what_position",getData("position"));
				m_binder.putLocal("vacancy_based",getData("location"));
				m_binder.putLocal("salary_range",getData("salaryRange"));
				m_binder.putLocal("employment_type",getData("jobType"));
				m_binder.putLocal("further_info",getData("addInfo"));
				m_binder.putLocal("DataFormName","CustomForm2");
				m_binder.putLocal("Subject",getData("subject"));
				m_binder.putLocal("emailTemplate","webApiRegisterYourVacancy");
				m_binder.putLocal("EmailID",getData("toEmail"));
				m_binder.putLocal("domainId",lEntityHaysWebsites.getlDomainId());
				m_binder.putLocal("state_county",getData("stateCountry"));
				
				SystemUtils.trace(TRACE_NAME, "Params : " + m_binder);
				
				m_service.executeServiceEx("HAYS_MAIL", true);
				
				this.m_binder.putLocal("StatusMessage", LocaleUtils.encodeMessage("wwWebApiOKMsg", null));
				this.m_binder.putLocal("StatusCode", "UC000");
			}
			catch (Exception e)
			{
				HandleExceptions(m_binder, "UC015", "wwMandatoryParams");
			}
		
		
	}
	
	public String getData(String pParamName) throws ServiceException
	{
		String returnString = "";
		try
		{
			returnString = m_binder.get(pParamName);
		}
		catch (Exception e)
		{
			throw new ServiceException("You must specify " + pParamName);
		}
		return returnString;
	}
}
