package hays.com.commonutils;

public class EntityHaysWebsites
{
	String lCountryRegion;
	String lDomainId;
	String lLanguageId;
	String lSiteId;
	String lDataFilePrefix;
	public String getlCountryRegion()
	{
		return lCountryRegion;
	}
	public void setlCountryRegion(String lCountryRegion)
	{
		this.lCountryRegion = lCountryRegion;
	}
	public String getlDomainId()
	{
		return lDomainId;
	}
	public void setlDomainId(String lDomainId)
	{
		this.lDomainId = lDomainId;
	}
	public String getlLanguageId()
	{
		return lLanguageId;
	}
	public void setlLanguageId(String lLanguageId)
	{
		this.lLanguageId = lLanguageId;
	}
	public String getlSiteId()
	{
		return lSiteId;
	}
	public void setlSiteId(String lSiteId)
	{
		this.lSiteId = lSiteId;
	}
	public String getlDataFilePrefix()
	{
		return lDataFilePrefix;
	}
	public void setlDataFilePrefix(String lDataFilePrefix)
	{
		this.lDataFilePrefix = lDataFilePrefix;
	}
	
}
