package hays.com.commonutils;

import intradoc.common.LocaleUtils;
import intradoc.common.ServiceException;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.DataResultSet;
import intradoc.data.ResultSet;
import intradoc.data.Workspace;
import intradoc.provider.Provider;
import intradoc.provider.Providers;
import intradoc.server.ServiceHandler;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class HaysWebApiUtils extends ServiceHandler
{
	public static DataResultSet executeHaysProviderSql(String pProviderName, String pRawSql) throws ServiceException, DataException
	{
		if ((pRawSql == null) || (pRawSql.length() == 0))
		{
			throw new ServiceException("You must specify a value for 'pRawSql'.");
		}
		Provider p = Providers.getProvider(pProviderName);
		if ((p == null) || (!p.isProviderOfType("database")))
		{
			throw new ServiceException("You the provider '" + pProviderName + "' is not a valid provider of type 'database'.");
		}
		Workspace ws = (Workspace) p.getProvider();
		ResultSet temp = ws.createResultSetSQL(pRawSql);
		DataResultSet result = new DataResultSet();
		result.copy(temp);
		ws.releaseConnection();
		return result;
	}

	public static DataResultSet executeHaysProviderQuery(String pProviderName, String pQueryName, DataBinder pBinder)
			throws ServiceException, DataException
	{
		if (pQueryName != null && !(pQueryName.trim().length() > 0))
		{
			throw new ServiceException("You must specify a value for 'pQueryName'.");
		}
		Provider p = Providers.getProvider(pProviderName);
		if ((p == null) || (!p.isProviderOfType("database")))
		{
			throw new ServiceException("You the provider '" + pProviderName + "' is not a valid provider of type 'database'.");
		}
		Workspace ws = (Workspace) p.getProvider();
		ResultSet temp = ws.createResultSet(pQueryName, pBinder);
		DataResultSet result = new DataResultSet();
		result.copy(temp);
		ws.releaseConnection();
		return result;
	}

	public static EntityHaysWebsites getHaysWebsitesData(DataResultSet pRsLocaleDetails) throws ServiceException, DataException
	{
		Vector vecLocaleDetails = new Vector();
		EntityHaysWebsites lEntityHaysWebsites = new EntityHaysWebsites();
		if (pRsLocaleDetails != null && pRsLocaleDetails.getNumRows() > 0)
		{
			vecLocaleDetails = pRsLocaleDetails.getRowValues(0);
			lEntityHaysWebsites.setlCountryRegion(vecLocaleDetails.elementAt(0).toString());
			lEntityHaysWebsites.setlDomainId(vecLocaleDetails.elementAt(1).toString());
			lEntityHaysWebsites.setlLanguageId(vecLocaleDetails.elementAt(2).toString());
			lEntityHaysWebsites.setlSiteId(vecLocaleDetails.elementAt(6).toString());
			lEntityHaysWebsites.setlDataFilePrefix(vecLocaleDetails.elementAt(7).toString());
		}
		return lEntityHaysWebsites;
	}

	public static Document parseXML(String pFilePath) throws ParserConfigurationException, SAXException, IOException
	{
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(true);
		DocumentBuilder builder = domFactory.newDocumentBuilder();
		Document document = builder.parse(pFilePath);
		return document;
	}

	public static Document parseXML(InputStream paramInputStream) throws ParserConfigurationException, SAXException, IOException
	{
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(true);
		DocumentBuilder builder = domFactory.newDocumentBuilder();
		builder.setEntityResolver(null);
		Document document = builder.parse(paramInputStream);
		return document;
	}

	public static ResultSet createResultSetFromData(ArrayList<String> pHeaderList, ArrayList<String> pAttrList)
	{
		DataResultSet rs = new DataResultSet(pHeaderList.toArray(new String[pHeaderList.size()]));
		int lSplitIndex = pHeaderList.size();

		List<List<String>> parts = chopList(pAttrList, lSplitIndex);
		for (List<String> lListOfData : parts)
		{
			rs.addRowWithList(lListOfData);
		}
		return rs;
	}

	private static <T> List<List<T>> chopList(List<T> list, final int L)
	{
		List<List<T>> parts = new ArrayList<List<T>>();
		final int N = list.size();
		for (int i = 0; i < N; i += L)
		{
			parts.add(new ArrayList<T>(list.subList(i, Math.min(N, i + L))));
		}
		return parts;
	}

	public static ArrayList<String> grabHTMLLinks(final String html)
	{
		Pattern patternTag = null;
		Pattern patternLink = null;
		String link = null;
		Matcher matcherTag, matcherLink;
		final String HTML_A_TAG_PATTERN = "(?i)<a([^>]+)>(.+?)</a>";
		final String HTML_A_HREF_TAG_PATTERN = "\\s*(?i)href\\s*=\\s*(\"([^\"]*\")|'[^']*'|([^'\">\\s]+))";
		patternTag = Pattern.compile(HTML_A_TAG_PATTERN);
		patternLink = Pattern.compile(HTML_A_HREF_TAG_PATTERN);
		ArrayList<String> result = new ArrayList<String>();
		matcherTag = patternTag.matcher(html);
		while (matcherTag.find())
		{
			String href = matcherTag.group(1); // href
			String linkText = matcherTag.group(2); // link text
			matcherLink = patternLink.matcher(href);
			while (matcherLink.find())
			{
				link = matcherLink.group(1); // link
				if (!("".equalsIgnoreCase(linkText) && "".equalsIgnoreCase(link)))
				{
					result.add(linkText);
					result.add(link.replaceAll("\"", ""));
				}
			}
		}
		return result;
	}

	public static void HandleExceptions(DataBinder pBinder, String pErrorCode, String pErrorStringKey) throws ServiceException
	{
		String msg = LocaleUtils.encodeMessage(pErrorStringKey, null);
		pBinder.putLocal("StatusMessage", LocaleUtils.encodeMessage(pErrorStringKey, null));
		pBinder.putLocal("StatusCode", pErrorCode);
		pBinder.removeResultSet("error");
		pBinder.m_resultSets.remove("error");
		throw new ServiceException(msg);
	}
	
	public static Integer getInt(String pData)
	{
		Integer lReturnValue = 0;
		try
		{
			if (pData != null)
			{
				lReturnValue = Integer.parseInt(pData);
			}
		}
		catch (Exception e)
		{

		}
		return lReturnValue;
	}
	
	public static boolean isNotNull(String pParamName)
	{
		if (pParamName != null && !"".equalsIgnoreCase(pParamName))
			return true;
		else
			return false;
	}
}
