package hays.co.uk;

import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.server.Service;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;



import sitestudio.SSLinkFunctions;

public class HaysGoogleSiteMapBuilder extends GoogleSiteMapBuilder {
	
	private List<Hashtable<String,String>> m_additionalContentMapList = null;
	private Service m_service = null;
	private String defaultSectionId = null;
	String m_projectSustomProperty = null;

	public HaysGoogleSiteMapBuilder(String siteId, String siteUrl,  Hashtable<String, String>  latestSectionsUpdatesMap, Service service, String property) {
		super(siteId, siteUrl, latestSectionsUpdatesMap);
		super.m_toAdditionalContent = true;
		this.m_service = service;
		this.m_projectSustomProperty = property;
	}
	
	/**
	 * For sections, whose Project Custom Property (env. variable) was set, we need to retrieve related
	 * content - content with metadata with the same name and value as the Project Custom Property.
	 * Query returns 2 column: metadata value (METATERM) and a list of associated dDocName@xWebsiteSection@dInDate (DDATE)
	 * 
	 * Note: xWebsiteSection is used to build this content url. If it's unknown than the defauld section (Env. variable)
	 * is used. TBC!
	 */
	protected String includeAdditionalContent(String nodeId) throws ServiceException  {
		StringBuffer writer = new StringBuffer();
		Hashtable<String,String> map = null;
		String[] listOfValues, listOfContentValues = null;
		String value, dDocName, dInDate, xWebsiteSection, url = null;
		
		SiteMapHandler sitemaphandler = (SiteMapHandler)m_service.getHandler("hays.co.uk.SiteMapHandler");
		String customPropValue = sitemaphandler.getNodeProperty(m_siteId, nodeId, m_projectSustomProperty, true);
		if( customPropValue != null && customPropValue.length() > 0) {
			customPropValue = customPropValue.replaceAll(";", "");
			debug("includeAdditionalContent() : " + nodeId + " - " + customPropValue);
			for( Iterator<Hashtable<String,String>> iter = m_additionalContentMapList.iterator(); iter.hasNext();) {
				map = iter.next();
				if( map.containsKey(customPropValue)) {
					value = map.get(customPropValue);
					listOfValues = value.split(",");
					for( int i = 0; i < listOfValues.length; i++) {
						value = listOfValues[i];
						debug(value);
						listOfContentValues = value.split("@");
						dDocName = listOfContentValues[0];
						xWebsiteSection = listOfContentValues[1];
						dInDate = listOfContentValues[2];
						if( xWebsiteSection.length() == 0 ) {
							xWebsiteSection = defaultSectionId;
						} else {
							xWebsiteSection = xWebsiteSection.substring(xWebsiteSection.indexOf(":")+1);
						}
						debug("includeAdditionalContent() : " + dDocName + ", " + xWebsiteSection + ", " + dInDate);
						String contentRelativeLink = SSLinkFunctions.computeLinkUrl(this.m_service, dDocName, xWebsiteSection, m_siteId, true);
						
						if(contentRelativeLink != null && !contentRelativeLink.equals("null")){
							url = m_siteUrl + SSLinkFunctions.computeLinkUrl(this.m_service, dDocName, xWebsiteSection, m_siteId, true);
							writer.append( populateSiteMap(url, "0.5", dInDate) );
						}
					}
				}
			}
		}
		return writer.toString();
	}
	
	public void setProjectCustomProperty(String property) {
		this.m_projectSustomProperty = property;
	}
	public List<Hashtable<String, String>> getAdditionalContentMapList() {
		return m_additionalContentMapList;
	}

	public void setAdditionalContentMapList(			List<Hashtable<String, String>> contentMapList) {
		m_additionalContentMapList = contentMapList;
	}

	public String getDefaultSectionId() {
		return defaultSectionId;
	}

	public void setDefaultSectionId(String defaultSectionId) {
		this.defaultSectionId = defaultSectionId;
	}
}
