package hays.co.uk;



import java.io.File;
import java.util.Properties;


import intradoc.common.ClassHelper;
import intradoc.common.ExecutionContext;
import intradoc.common.FileUtils;
import intradoc.common.ServiceException;
import intradoc.common.SystemUtils;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.ResultSet;
import intradoc.data.Workspace;
import intradoc.server.DirectoryLocator;
import intradoc.server.IdcSystemLoader;
import intradoc.server.ScheduledSystemEvents;
import intradoc.server.Service;
import intradoc.server.script.ScriptExtensionUtils;
import intradoc.shared.FilterImplementor;
import intradoc.shared.SharedObjects;

public class SiteMapBuildEvent implements FilterImplementor {
	
	
	
	public int doFilter(Workspace ws, DataBinder eventData, ExecutionContext cxt)	throws DataException, ServiceException {
		debug("SiteMapBuildEvent: " + cxt);
		if (cxt == null || !(cxt instanceof Service)) {
			debug("SiteMapBuildEvent: not a service" );
			return 0;
		}
		// get the action, and be sure to only execute your code if the 'action'
		// matches the value for action in the 'CustomScheduledEvents' table 
		String action  = eventData.getLocal("action");
		//System.out.println("\n\nSiteMapBuildEvent filter!");
		// execute the daily event, or the hourly event
		if (action.equals("SiteMapEvent"))	{
			rebuildSiteMap(ws, eventData, (Service)cxt);
			return FINISHED;
		}
		
		// Return CONTINUE so other filters have a chance at it.
		return CONTINUE;
	}
	
	

	
	/**
	 * Build sitemap.xml 
	 * @return an error string, or null if no error
	 */
	protected void rebuildSiteMap(Workspace ws, DataBinder eventData, Service service) throws DataException, ServiceException
	{
		// you MUST perform at least one update
		update("SiteMapEvent", "event starting...", ws);
		
		debug(" rebuilding sitemap.xml as a custom event... should be run around midnight: " + service);
		
		try {
			
		//	Service service = ScriptExtensionUtils.;
			
			// get all sites
			Properties properties = new Properties();
			callServiceHandler(service, "getAllSites", properties, "SiteIds");
			ResultSet sitesRS = eventData.getResultSet("SiteIds");
			if( sitesRS == null || !sitesRS.first())
				return;
			
			debug("Site Map event - loop sites: " + sitesRS);
			DataBinder binder;
			String siteId = null;
			do {
				siteId = sitesRS.getStringValueByName("siteId");
				// update lock files for clostered env
				String pathBase = SiteMapHandler.getDataDir(siteId);
				FileUtils.checkOrCreateDirectory(pathBase, 1);
				FileUtils.createLockIfNeeded(pathBase );
				File file = new File(pathBase, "lockwait.dat");
				FileUtils.touchFile(file.getPath());
				
				binder = new DataBinder();
				binder.putLocal("siteId", siteId) ;
				binder.putLocal("toRebuild", "true");
				callServiceHandler(service, "getGoogleSiteMap", properties, "siteMapXml");
			} while(sitesRS.next());
		} catch(Exception ex ) {
				debug(ex);
		}
		
		// event has finished!
		update("SiteMapEvent", "event finished successfully", ws);
	}
	
	
	
	/**
	 * Update the state of the event. Must be done at least once to tell the content server
	 * when the scehduled event is finished.
	 */
	protected void update(String action, String msg, Workspace workspace) throws ServiceException, DataException
	{
		long curTime = System.currentTimeMillis();
		ScheduledSystemEvents sse = IdcSystemLoader.getOrCreateScheduledSystemEvents(workspace);
		sse.updateEventState(action, msg, curTime);
	}
	

	String callServiceHandler(Service service, String methodName, Properties properties, String returnValue) throws ServiceException {
        String resultStr = null;
        DataBinder databinder;
        Properties properties1;
        databinder = service.getBinder();
        if (databinder == null) {
            return null;
        }
        properties1 = databinder.getLocalData();
        databinder.setLocalData(properties);
        SiteMapHandler ssservicehandler = (SiteMapHandler)service.getHandler("hays.co.uk.SiteMapHandler");
        if (ssservicehandler != null) {
            ClassHelper classhelper = new ClassHelper();
            classhelper.m_class = ssservicehandler.getClass();
            classhelper.m_obj = ssservicehandler;
            classhelper.invoke(methodName);
            resultStr = databinder.getLocal(returnValue);
        }
        databinder.setLocalData(properties1);
        return resultStr;
    }
	

	
	
	
	

	public static void debug(String message) {
		SystemUtils.trace("sitemap",  message);
	//	System.out.println(message);
	}

	public static void debug(Exception ex) {
		SystemUtils.trace("sitemap", "\nException :" + ex);
		ex.printStackTrace();
	}
}
